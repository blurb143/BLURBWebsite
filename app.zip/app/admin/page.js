'use client'

import { useEffect, useState } from 'react'
import { signIn, signOut, getSession } from '@/lib/supabase/auth'
import { supabase } from '@/lib/supabase/client'
import { uploadToCloudinary } from '@/lib/cloudinary'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import { Toaster } from '@/components/ui/toaster'
import { LogOut, Plus, Edit, Trash2, Upload, Image as ImageIcon } from 'lucide-react'

export default function AdminPage() {
  const [session, setSession] = useState(null)
  const [loading, setLoading] = useState(true)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [projects, setProjects] = useState([])
  const [bookings, setBookings] = useState([])
  const [isProjectDialogOpen, setIsProjectDialogOpen] = useState(false)
  const [editingProject, setEditingProject] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [projectForm, setProjectForm] = useState({
    title: '',
    category: 'Photography',
    media_url: '',
    thumbnail_url: ''
  })
  const { toast } = useToast()

  useEffect(() => {
    checkSession()
  }, [])

  useEffect(() => {
    if (session) {
      fetchProjects()
      fetchBookings()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session])

  const checkSession = async () => {
    const { session } = await getSession()
    setSession(session)
    setLoading(false)
  }

  const handleSignIn = async (e) => {
    e.preventDefault()
    const { data, error } = await signIn(email, password)
    
    if (error) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      })
    } else {
      setSession(data.session)
      toast({
        title: 'Success',
        description: 'Signed in successfully'
      })
    }
  }

  const handleSignOut = async () => {
    await signOut()
    setSession(null)
    toast({
      title: 'Signed out',
      description: 'You have been signed out successfully'
    })
  }

  const fetchProjects = async () => {
    try {
      const response = await fetch('/api/projects')
      const data = await response.json()
      setProjects(data)
    } catch (error) {
      console.error('Error fetching projects:', error)
    }
  }

  const fetchBookings = async () => {
    if (!session?.access_token) return
    
    try {
      const response = await fetch('/api/admin/bookings', {
        headers: {
          'Authorization': `Bearer ${session.access_token}`
        }
      })
      const data = await response.json()
      setBookings(data)
    } catch (error) {
      console.error('Error fetching bookings:', error)
    }
  }

  const handleImageUpload = async (e, field) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploading(true)
    try {
      const result = await uploadToCloudinary(file, 'image')
      
      if (result.error) {
        throw new Error(result.error)
      }

      setProjectForm(prev => ({
        ...prev,
        [field]: result.url
      }))

      toast({
        title: 'Success',
        description: 'Image uploaded successfully'
      })
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to upload image',
        variant: 'destructive'
      })
    } finally {
      setUploading(false)
    }
  }

  const handleProjectSubmit = async (e) => {
    e.preventDefault()
    
    if (!session?.access_token) return

    try {
      const url = editingProject 
        ? `/api/admin/projects/${editingProject.id}`
        : '/api/admin/projects'
      
      const method = editingProject ? 'PUT' : 'POST'

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify(projectForm)
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: editingProject ? 'Project updated' : 'Project created'
        })
        setIsProjectDialogOpen(false)
        setEditingProject(null)
        setProjectForm({
          title: '',
          category: 'Photography',
          media_url: '',
          thumbnail_url: ''
        })
        fetchProjects()
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save project',
        variant: 'destructive'
      })
    }
  }

  const handleDeleteProject = async (id) => {
    if (!confirm('Are you sure you want to delete this project?')) return
    
    if (!session?.access_token) return

    try {
      const response = await fetch(`/api/admin/projects/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${session.access_token}`
        }
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Project deleted'
        })
        fetchProjects()
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete project',
        variant: 'destructive'
      })
    }
  }

  const handleEditProject = (project) => {
    setEditingProject(project)
    setProjectForm({
      title: project.title,
      category: project.category,
      media_url: project.media_url || '',
      thumbnail_url: project.thumbnail_url || ''
    })
    setIsProjectDialogOpen(true)
  }

  const handleUpdateBookingStatus = async (bookingId, status) => {
    if (!session?.access_token) return

    try {
      const response = await fetch(`/api/admin/bookings/${bookingId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({ status })
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Booking status updated'
        })
        fetchBookings()
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update booking',
        variant: 'destructive'
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-neutral-400">Loading...</p>
      </div>
    )
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-neutral-900 border-neutral-800">
          <CardHeader>
            <CardTitle className="text-2xl font-light text-center">Admin Login</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSignIn} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-neutral-800 border-neutral-700"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-neutral-800 border-neutral-700"
                  required
                />
              </div>
              <Button type="submit" className="w-full bg-white text-black hover:bg-neutral-200">
                Sign In
              </Button>
            </form>
          </CardContent>
        </Card>
        <Toaster />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black">
      <Toaster />
      
      {/* Header */}
      <header className="border-b border-neutral-800 px-6 py-4">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-light">Admin Dashboard</h1>
          <Button variant="ghost" onClick={handleSignOut}>
            <LogOut className="mr-2 h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <Tabs defaultValue="projects" className="space-y-6">
          <TabsList className="bg-neutral-900 border border-neutral-800">
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="bookings">Bookings</TabsTrigger>
          </TabsList>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-light">Manage Projects</h2>
              <Dialog open={isProjectDialogOpen} onOpenChange={setIsProjectDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    className="bg-white text-black hover:bg-neutral-200"
                    onClick={() => {
                      setEditingProject(null)
                      setProjectForm({
                        title: '',
                        category: 'Photography',
                        media_url: '',
                        thumbnail_url: ''
                      })
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Project
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-neutral-900 border-neutral-800 max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>{editingProject ? 'Edit Project' : 'Add New Project'}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleProjectSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="title">Project Title</Label>
                      <Input
                        id="title"
                        value={projectForm.title}
                        onChange={(e) => setProjectForm({...projectForm, title: e.target.value})}
                        className="bg-neutral-800 border-neutral-700"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="category">Category</Label>
                      <Select
                        value={projectForm.category}
                        onValueChange={(value) => setProjectForm({...projectForm, category: value})}
                      >
                        <SelectTrigger className="bg-neutral-800 border-neutral-700">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-neutral-900 border-neutral-800">
                          <SelectItem value="Photography">Photography</SelectItem>
                          <SelectItem value="Videography">Videography</SelectItem>
                          <SelectItem value="Editing">Editing</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="thumbnail">Thumbnail Image</Label>
                      <div className="flex gap-2">
                        <Input
                          id="thumbnail"
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, 'thumbnail_url')}
                          className="bg-neutral-800 border-neutral-700"
                          disabled={uploading}
                        />
                        {projectForm.thumbnail_url && (
                          <Button type="button" variant="outline" size="icon" disabled>
                            <ImageIcon className="h-4 w-4 text-green-500" />
                          </Button>
                        )}
                      </div>
                      {projectForm.thumbnail_url && (
                        <img src={projectForm.thumbnail_url} alt="Thumbnail preview" className="w-32 h-32 object-cover rounded mt-2" />
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="media">Main Media (Optional)</Label>
                      <Input
                        id="media"
                        value={projectForm.media_url}
                        onChange={(e) => setProjectForm({...projectForm, media_url: e.target.value})}
                        className="bg-neutral-800 border-neutral-700"
                        placeholder="Enter media URL or upload via Cloudinary"
                      />
                    </div>

                    <div className="flex gap-2 pt-4">
                      <Button 
                        type="submit" 
                        className="flex-1 bg-white text-black hover:bg-neutral-200"
                        disabled={uploading}
                      >
                        {uploading ? 'Uploading...' : (editingProject ? 'Update Project' : 'Create Project')}
                      </Button>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setIsProjectDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <Card className="bg-neutral-900 border-neutral-800">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="border-neutral-800">
                      <TableHead>Thumbnail</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projects.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-neutral-500 py-8">
                          No projects yet. Create your first project!
                        </TableCell>
                      </TableRow>
                    ) : (
                      projects.map((project) => (
                        <TableRow key={project.id} className="border-neutral-800">
                          <TableCell>
                            <div className="w-16 h-16 bg-neutral-800 rounded overflow-hidden">
                              {project.thumbnail_url ? (
                                <img src={project.thumbnail_url} alt={project.title} className="w-full h-full object-cover" />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                  <ImageIcon className="h-6 w-6 text-neutral-700" />
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{project.title}</TableCell>
                          <TableCell>
                            <span className="text-xs px-2 py-1 bg-neutral-800 rounded">{project.category}</span>
                          </TableCell>
                          <TableCell className="text-neutral-400 text-sm">
                            {new Date(project.created_at).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => handleEditProject(project)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => handleDeleteProject(project.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings" className="space-y-6">
            <h2 className="text-xl font-light">Client Bookings</h2>
            
            <Card className="bg-neutral-900 border-neutral-800">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="border-neutral-800">
                      <TableHead>Client</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Service</TableHead>
                      <TableHead>Event Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Message</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bookings.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-neutral-500 py-8">
                          No bookings yet.
                        </TableCell>
                      </TableRow>
                    ) : (
                      bookings.map((booking) => (
                        <TableRow key={booking.id} className="border-neutral-800">
                          <TableCell className="font-medium">{booking.client_name}</TableCell>
                          <TableCell className="text-neutral-400">{booking.client_email}</TableCell>
                          <TableCell>
                            <span className="text-xs px-2 py-1 bg-neutral-800 rounded">{booking.service_type}</span>
                          </TableCell>
                          <TableCell className="text-neutral-400 text-sm">
                            {new Date(booking.event_date).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <Select
                              value={booking.status}
                              onValueChange={(value) => handleUpdateBookingStatus(booking.id, value)}
                            >
                              <SelectTrigger className="w-32 bg-neutral-800 border-neutral-700">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-neutral-900 border-neutral-800">
                                <SelectItem value="New">New</SelectItem>
                                <SelectItem value="Replied">Replied</SelectItem>
                                <SelectItem value="Completed">Completed</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell className="max-w-xs truncate text-neutral-400 text-sm">
                            {booking.message}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
